"""One invocation synthesizes FULL SHA3 and standalone CORE at every requested period.
Requires a successful complete run_all_rtl.py with identical source files.
Example: python run_sweep.py --periods 10 8 6 4 2 1 --process TSMC40
"""
from __future__ import print_function, division
import argparse
import csv
from datetime import datetime
import hashlib
import json
import math
import os
from paper_compat import Path, emit, run_process, which, isfinite, csv_open, DictWriter
import re
import shutil
import subprocess

SYN=Path(__file__).resolve().parent
ROOT=SYN.parent
NUMBER=r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?'
FIELDS=['version','scope','period_ns','status','area_library_units','dynamic_power_mw',
        'leakage_power_mw','total_power_mw','worst_slack_ns','e2e_cycles_4096B',
        'standalone_core_cycles','full_throughput_gbps','core_rate_throughput_gbps',
        'estimated_energy_per_bit_pj','full_power_core_normalized_pj',
        'power_method','raw_directory','error']


def read(path): return path.read_text(encoding='utf-8',errors='replace')


def number(pattern,text,label):
    match=re.search(pattern,text,re.I|re.M)
    if not match: raise ValueError('Missing '+label)
    value=float(match.group(1))
    if not isfinite(value):raise ValueError('Nonfinite '+label)
    return value


def power(text,label):
    match=re.search(re.escape(label)+r'\s*=\s*('+NUMBER+r')\s*([munp]?W)\b',text,re.I)
    if not match:raise ValueError('Missing power value/unit: '+label)
    scales={'w':1000,'mw':1,'uw':.001,'nw':.000001,'pw':.000000001}
    return float(match.group(1))*scales[match.group(2).lower()]


def require_ns_time_unit(text):
    # DC R-2020.09: Time_unit : 1.0e-09 Second(ns)
    # Also accept equivalent spellings such as Time Units : 1ns.
    match=re.search(r'^\s*Time[ _]+Units?\s*[:=]\s*('+NUMBER+
                    r')\s*(seconds?|ns|ps|us|ms|s)\b',text,re.I|re.M)
    if not match:
        raise ValueError('Missing/unrecognized time unit; inspect units.rpt')
    scale={'second':1e9,'seconds':1e9,'s':1e9,'ms':1e6,'us':1e3,'ns':1.0,'ps':1e-3}
    ns=float(match.group(1))*scale[match.group(2).lower()]
    if not isfinite(ns) or abs(ns-1.0)>1e-12:
        raise ValueError('Expected 1 ns time unit, got {} ns; inspect units.rpt'.format(ns))
    return ns


def parse_reports(directory,period,scope,rtl):
    report=directory/'02_SYN/Report'
    for name in ('COMPLETE','area.rpt','power.rpt','timing.rpt','constraints.rpt',
                 'check_design.rpt','check_timing.rpt','qor.rpt','protection_instances.csv',
                 'clocks.rpt','ports.rpt','references.rpt','activity.rpt','units.rpt','run_metadata.txt'):
        if not (report/name).is_file() or not (report/name).stat().st_size:
            raise ValueError('Missing report: '+name)
    for ext in ('v','ddc','sdc','sdf'):
        if not list((directory/'02_SYN/Netlist').glob('*.'+ext)):raise ValueError('Missing netlist '+ext)
    log=read(directory/'02_SYN/dc.log')
    if re.search(r'^\s*(?:Error:|Fatal:)',log,re.M):raise ValueError('DC reported an error; inspect dc.log')
    # check_timing warns explicitly about unconstrained endpoints / clocks.
    checks=read(report/'check_timing.rpt')
    if re.search(r'Warning:.*(?:no clock|not constrained|unconstrained)',checks,re.I):
        raise ValueError('Unconstrained timing detected; inspect check_timing.rpt')
    units=read(report/'units.rpt')
    require_ns_time_unit(units)
    area=number(r'Total cell area\s*:\s*('+NUMBER+')',read(report/'area.rpt'),'cell area')
    pwr=read(report/'power.rpt')
    dynamic=power(pwr,'Total Dynamic Power'); leakage=power(pwr,'Cell Leakage Power')
    if min(area,dynamic,leakage)<0 or area==0:raise ValueError('Invalid area/power')
    slack=number(r'^worst_slack_ns=('+NUMBER+')',read(report/'run_metadata.txt'),'slack')
    full_cycles=int(rtl['message']['e2e_cycles']); core_cycles=int(rtl['standalone_core_cycles'])
    if full_cycles<=0 or core_cycles<=0:raise ValueError('Invalid latency')
    full_tp=32768/(full_cycles*period)
    core_tp=1088/(core_cycles*period)
    total=dynamic+leakage
    # mW / Gbit/s = pJ/bit. This is a vectorless power-normalized estimate.
    constraints=read(report/'constraints.rpt')
    constraint_fail=slack>=0 and 'VIOLATED' in constraints
    valid=slack>=0 and not constraint_fail
    return dict(area_library_units=area,dynamic_power_mw=dynamic,leakage_power_mw=leakage,
                total_power_mw=total,worst_slack_ns=slack,
                e2e_cycles_4096B=full_cycles,standalone_core_cycles=core_cycles,
                full_throughput_gbps=full_tp if valid and scope=='full' else '',
                core_rate_throughput_gbps=core_tp if valid else '',
                estimated_energy_per_bit_pj=total/(full_tp if scope=='full' else core_tp) if valid else '',
                full_power_core_normalized_pj=total/core_tp if valid and scope=='full' else '',
                status='VALID' if valid else ('CONSTRAINT_FAIL' if constraint_fail else 'TIMING_FAIL'))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--periods',type=float,nargs='+',default=[10,8,6,4,2,1])
    parser.add_argument('--process',default='TSMC40',choices=['TSMC40','TSMC28','TSMC16','UMC018'])
    parser.add_argument('--dc',default='dcnxt_shell')
    parser.add_argument('--setup',type=Path,help='Use an existing .synopsys_dc.setup instead of Makefile setup_dc')
    args=parser.parse_args()
    if any(not isfinite(p) or p<=0 for p in args.periods):parser.error('Periods must be finite and >0')
    if len(set(args.periods))!=len(args.periods):parser.error('Duplicate periods')
    summary=ROOT/'rtl_latest.json'
    if not summary.exists():raise SystemExit('[FAIL] Run the complete 00_TESTBED/run_all_rtl.sh first')
    rtl=json.loads(read(summary))
    if rtl.get('status')!='PASS' or rtl.get('version')!=ROOT.name:raise SystemExit('[FAIL] Invalid RTL summary')
    for name,expected in rtl['source_sha256'].items():
        p=ROOT/name
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:
            raise SystemExit('[FAIL] Source changed since RTL tests: '+name)
    actual={str(p.relative_to(ROOT)) for d in ('00_TESTBED','01_RTL') for p in (ROOT/d).iterdir()
            if p.is_file() and (p.suffix in ('.sv','.f','.py','.sh') or p.name=='Makefile')}
    if actual!=set(rtl['source_sha256']):raise SystemExit('[FAIL] Source file list changed since RTL tests')
    out=ROOT/'results'/'sweep'/datetime.now().strftime('%Y%m%d_%H%M%S')
    out.mkdir(parents=True,exist_ok=False)
    if args.setup:
        setup=args.setup.resolve()
    else:
        setup=SYN/'.synopsys_dc.setup'
        with (out/'setup.log').open('w') as f:
            run_process(['make','-f','../00_TESTBED/Makefile','setup_dc','PROCESS='+args.process],
                           cwd=SYN,stdout=f,stderr=subprocess.STDOUT,check=True)
    if not setup.is_file():raise SystemExit('[FAIL] Synthesis setup missing: '+str(setup))
    shutil.copy2(setup,out/'synopsys_dc.setup')
    shutil.copy2(summary,out/'rtl_summary.json')
    (out/'request.json').write_text(json.dumps(dict(version=ROOT.name,periods_ns=args.periods,
            process=args.process,dc=args.dc,power_method='vectorless, 0.1 toggles/cycle, static probability 0.5',
            timestamp=datetime.now().isoformat()),indent=2),encoding='utf-8')
    rows=[]; errors=0
    for period in args.periods:
        if errors: break
        for scope in ('full','core'):
            point=out/'{}_{:g}ns'.format(scope, period); point.mkdir()
            for folder in ('00_TESTBED','01_RTL','02_SYN'):
                dst=point/folder; dst.mkdir()
                for p in (ROOT/folder).iterdir():
                    if p.is_file():shutil.copy2(p,dst/p.name)
            shutil.copy2(setup,point/'02_SYN/.synopsys_dc.setup')
            env=os.environ.copy();env.update(CLK_PERIOD=str(period),PAPER_SCOPE=scope,PAPER_VERSION=ROOT.name)
            row=dict(version=ROOT.name,scope=scope,period_ns=period,status='ERROR',
                     power_method='vectorless',raw_directory=str(point.relative_to(out)),error='')
            emit('[INFO] {} {} {:g} ns'.format(ROOT.name, scope, period),flush=True)
            try:
                with (point/'02_SYN/dc.log').open('w') as f:
                    run_process([args.dc,'-f','paper_syn.tcl'],cwd=point/'02_SYN',env=env,
                                   stdout=f,stderr=subprocess.STDOUT,check=True)
                row.update(parse_reports(point,period,scope,rtl))
                emit("[{}] {} {:g} ns".format(row['status'], scope, period),flush=True)
            except Exception as exc:
                row['error']=str(exc);errors+=1;emit('[FAIL] '+str(exc),flush=True)
            rows.append(row)
            with csv_open(out/'sweep.csv') as f:
                w=DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
            if errors: break
    valid={s:sum(r['status']=='VALID' and r['scope']==s for r in rows) for s in ('full','core')}
    result=dict(status='PASS' if not errors and all(valid.values()) else 'FAIL',valid_points=valid,
                tool_or_report_errors=errors,results=str(out),note='TIMING_FAIL rows are not performance results.')
    (out/'sweep_summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    emit(('[SUCCESS] Sweep completed; usable full/core data saved. ' if result['status']=='PASS' else
           '[FAIL] Sweep needs attention; see sweep.csv and raw logs. ')+str(out))
    raise SystemExit(0 if result['status']=='PASS' else 1)


if __name__=='__main__':main()
